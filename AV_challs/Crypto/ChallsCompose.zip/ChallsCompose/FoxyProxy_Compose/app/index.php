<?php error_reporting(0); 
setcookie("sessToken", "", time() - 3600);
include "connection.php";
?>
<!DOCTYPE html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="loginstyles.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body>



<div class="top">    
<h1><u>Login to play game</u></h1><br>

<div class="form">
    <form method="POST" action="#">
        <label><i class="fas fa-user"> Username</i></label><br>
        <input type="text" name="uname" maxlength="100" placeholder="Enter username here"></input><br><br>
        <label><i class="fas fa-key"> Password</i></label><br>
        <input type="password" name="passwd" maxlength="100" placeholder="Enter password here"></input><br><br>
        <button name="login">Submit</button><br>
        <br>
        <a href="signup.php">Click here to signup</a>
    </form>
</div>
</div>
</body>
</html>
<?php
if(isset($_POST['login']) and $_POST['uname'] != "" and $_POST['passwd'] != "")
{
    $user=mysqli_real_escape_string($conn,$_POST['uname']);
    $password=mysqli_real_escape_string($conn,$_POST['passwd']);
    $query="select * from users where uname='".$user."' and password='".md5($password)."'";
    $exec=mysqli_query($conn,$query);
    if(mysqli_num_rows($exec)==1)
    {
        $row=mysqli_fetch_array($exec);
        $sess_cookie=$row['uname'].":".hash("sha512","5eSsi0nS3crEtCTFt0Ken123".$row['uname']);
        setcookie("sessToken", $sess_cookie); 
        echo "<script>window.open('dash.php', '_self');</script>";
    }


}
?>