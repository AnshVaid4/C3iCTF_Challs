<?php error_reporting(0); 
include "connection.php";
$query="select id,uname from users";
$exec=mysqli_query($conn,$query);
?>
<center><table>
        <tr><th align="center" style="border: 1px solid black;" width=250px><u>Id</u></th><th align="center" style="border: 1px solid black;" width=250px><u>Users</u></th></tr>
        <?php
while($row=mysqli_fetch_array($exec))
{
    ?>
        <tr><td align="center" style="border: 1px solid black;" width=250px><?php echo $row['id'];?></td><td align="center" style="border: 1px solid black;" width=250px><?php echo $row['uname'];?></td></tr><br>
    <?php
}
?>
</table></center>