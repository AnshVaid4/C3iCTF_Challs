<?php error_reporting(0);
if(!isset($_COOKIE['sessToken']))
{
    session_destroy();
    echo "<script>alert('Invalid Login');window.open('index.php', '_self');</script>";
}
$tokenstr=explode(":",urldecode($_COOKIE['sessToken']));
$token=$tokenstr[1];
if(strpos($tokenstr[0],'Admin') and $token===hash("sha512","5eSsi0nS3crEtCTFt0Ken123".$tokenstr[0]))
{
    echo "Your flag is C3iCenter{F1n4l1y_g0T_tH3_fl4G}";

}
else if ($tokenstr[1]!==hash("sha512","5eSsi0nS3crEtCTFt0Ken123".$tokenstr[0]))
{
    echo "Invalid token"."<br>";
    echo hash("sha512","5eSsi0nS3crEtCTFt0Ken123".$tokenstr[0]);
}
else
{?>
  <!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title><?php  echo "Welcome guest | $tokenstr[0]"."<br>";  ?></title>
  
<link rel="stylesheet" href="./style.css">
<style>
      .container {
        width: 150px;
        height: 150px;
        position: relative;
        margin: 30px;
      }
      .box {
        width: 100%;
        height: 100%;
        position: absolute;
        top: 0;
        left: 0;
        opacity: 0.7;
        background: #0057e3;
      }
      .overlay {
        z-index: 9;
        margin: 30px;
        background: #009938;
      }
      h1{
        color:white;
      }
    </style>
</head>
<body>
<!-- partial:index.partial.html -->
<body>
<canvas id="canvas"></canvas>
    <div class="container">
      <div class="box"></div>
      <div class="box overlay"><h1><?php echo "Welcome guest | $tokenstr[0]"."<br>";?></h1></div>
    </div>
    <canvas id="canvas"></canvas>
    
</body>
<!-- partial -->
  <script  src="./script.js"></script>

</body>
</html>
<?php 
}

?>

