#!/bin/bash
#service apache2 start
source /etc/apache2/envvars
apache2 -D FOREGROUND

#service mysql start

#mysql -u root -p" " -e "create database crypto"
#mysql -u root -p" " crypto < /root/account.sql
