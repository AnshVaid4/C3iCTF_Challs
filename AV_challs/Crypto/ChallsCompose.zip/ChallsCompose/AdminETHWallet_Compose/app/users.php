<?php 
error_reporting(0);
include "connection.php";
$query="select id,username,password from account";
$exec=mysqli_query($conn,$query);
?>
<center><table>
        <tr><th align="center" style="border: 1px solid black;" width=250px><u>Id</u></th><th align="center" style="border: 1px solid black;" width=250px><u>Username</u></th><th align="center" style="border: 1px solid black;" width=250px><u>Password</u></th><th align="center" style="border: 1px solid black;" width=250px><u>Comments</u></th></tr>
        <?php
while($row=mysqli_fetch_array($exec))
{
    ?>
        <tr><td align="center" style="border: 1px solid black;" width=250px><?php echo $row['id'];?></td><td align="center" style="border: 1px solid black;" width=250px><?php echo $row['username'];?></td><td align="center" style="border: 1px solid black;" width=250px><?php echo $row['password'];?></td><td align="center" style="border: 1px solid black;" width=250px><a href="#">Hidden</a></td></tr><br>
    <?php
}
?>
</table></center>
