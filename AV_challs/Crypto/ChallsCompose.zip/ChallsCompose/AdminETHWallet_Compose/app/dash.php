<!DOCTYPE html>
<head>
    <title>What's my wallet address</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body>
<?php
error_reporting(0);
session_start();
if($_SESSION['name']=="")
{
    session_destroy();
    header("Location: index.php");
}
if($_SESSION['name']=="Admin"){
    ?>
    <!-- Public Key:MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAnIvm0W5OkFmJm5gLP9udkTqNAIn1PHhJFKulTATLvYWLrW5ip0+eI9yJeV4Dg6Ku03OPncebEgcoOGuQ5spZ5VtqD3B2qfxMHJ+n3Bz0Hw73tEJ2oOnRtHebWltKJzbuO6QSupedIFKqYHBJQ5a5J2S3p/IfS9tKICv/X2vl10pgtG7Qj7mbz8/Dde/kKCpVIR0FG+xIzFOMY/wDIeOXoVjrDce0XlqJgE0FDIXwMDL4L9wLRBdD9h+1lcB6l2XMQCRtad8mZYRWiJmbbG9yzRv8Fnf01o1NK1skeAxAjEaVle4T5zSIhDBvhc3LQXMCrvwGthkfW+sI6uFnscYA7eCjYIpXvHCsRfFdHKVFnuEi4Hj/efcDdIx9x4MzErFaCcEsfzxPyREp+Xu/rwG3N2HR25NZsStJdXeMjZN870R++/KuhAa3X3Nz295baG6KJBKLIMuaa53NZXAROTyEuGbRvHchd6po8p6wpoRV7qJO+H1LPAdtJrAISvD7ZOctosIoi6qM1/L7B3zzsffYZthGU+GFD1NGg8onhW3wwIZlttV2SLwhaRkReuyAVWJsSDqYx8FutSJUZMsY+lf7YuPH46EPQ8CXkkSMPYBvZLe7uGq//lzEuTGys3n0qqOmz/kOJH3x7xvQEwlvDjskQned9yj1SQzSut3Mv9ynM3sCAwEAAQ== -->
    <?php
    }
?>
<div class="top">    
<br>
<div class="">
<?php 

if($_SESSION['name']!=null)
{
if($_SESSION['name']=="Admin"){
?>
<a href="index.php">Logout</a><br><br>
<!-- Users can be managed from users.php file -->
<!-- Find Cipher to decipher using key-->
<center><img src="zfx/comment.jpg" height="500px" width="500px"></center>
<?php
}
else{


?>

<a href="index.php">Logout</a>
<center><h1><u>You are close</u></h1></center><br>
<div class="a">
<center><img src="zfx/gfg.PNG" width="480" height="270" frameBorder="0" allowFullScreen></img></center>
    <!-- Cipher: JMiVGh79U40Yv15bmFOSk4YNHoLo+Xu8eYosfJ1z2wgfqdwzvdLjIDORLxW3fX3iJ1LUVAjSqN+QmaXi61joy6pNVTpkt2j85+6eT112VJxx9LVi2N/0rBmlUw5C9HQnh/MRB+WSWvhUQ5nPJPacBjlFoxmzdM221wBtSxZ6gXmp7W6wr2EtogY3vZDG5WM+pLneKGgyhK9MIamHlwNp12y6M3V5MJbkAhJkkGPg8rAc6QimSA2xAUM7DSjyV/ZofzKpNLrCgB0ullS/RXrX/hoZ7yDfwWrO0DZghcxiAWEpon7BdjR34Eb6WKjdgvWty67AuHoVVh98W03QuLuF3WiLu9MBNwow51vElO/pNFm+4cfeedT/k+48fdKDxsfwTAXCrNvMwhIqdJSdSU7Z05rn7fujkzg+Rv4F4GM1Q+uOaRqoEwTreyr7dLHdUF5XbL3MF88bNQVfTKzepJhFF2rY5CVJzIVPxGgqywDZ/tGD/BDRgVqjTS6i0hkPSmVNHeSlWFhYuGAGJV5AYhFxhZtSuekRYRklwPX9Jic66e/pzFPjnO2CsnAS5rHoxviD0NzWFL8rTws9ksyXP1yd+njdFsUlRsDBbT6ihDw8To7k5VlSQsQq8xGqCuC9tlJGkrZ+mSpqTMhQItyrV9w1p61JO1AzDGjA/Ehtl/yh7Ek= -->

        <!-- Find key to decipher-->
 
</div>

<br>
<br>
<?php }} ?>

</body>
</html>

