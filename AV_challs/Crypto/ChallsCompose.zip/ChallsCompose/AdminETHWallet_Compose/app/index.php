<?php      error_reporting(0);  session_destroy();
setcookie("sessToken", "", time() - 3600);
include "connection.php";
?>
<!DOCTYPE html>
<head>
    <title>What's my wallet address</title>
    <link rel="stylesheet" href="loginstyles.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body>



<div class="top">    
<h1><u>Login</u></h1><br>

<div class="form">
    <form method="POST" action="#">
        <label><i class="fas fa-user"> Username</i></label><br>
        <input type="text" name="uname" maxlength="100" placeholder="Enter username here"></input><br><br>
        <label><i class="fas fa-key"> Password</i></label><br>
        <input type="password" name="passwd" maxlength="100" placeholder="Enter password here"></input><br><br>
        <button name="login">Submit</button><br>
        <br>
        <a href="signup.php">Click here to signup</a>
    </form>
</div>
</div>
</body>
</html>
<?php
if(isset($_POST['login']) and $_POST['uname'] != "" and $_POST['passwd'] != "")
{
    $user=$_POST['uname'];
    $password=$_POST['passwd'];
    $query="select * from account where username='".$user."' and password='".hash('sha512', $password)."'";
    $exec=mysqli_query($conn,$query);
    if(mysqli_num_rows($exec)==1)
    {
        session_start();
        $row=mysqli_fetch_array($exec);
        $_SESSION['name']=$row['username'];
        // echo $_SESSION['name'];
        header("Location: dash.php");
    }


}
?>
