<!DOCTYPE html>
<head>
<title>What's my wallet address</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body>
<div class="top">    
<a href="index.php">Logout</a>
<h3><center>Find the passphrase of digital lock to get the flag. The passphrase is same as the wallet address of the <b>ETH</b> wallet. </center></h3><br>
<br>
<div class="key"><center><img src="image.PNG" height="300px" width="400px"></center>

<div class="left">
</div>
<div class="form">
    <form method="POST" action="#">
        <label><i class="fas fa-user-lock"> Digital Safe</i></label><br>
        <i class="fas fa-key"></i><input type="text" name="address" maxlength="100" placeholder="Please enter the key to open safe and retrieve flag"></input><br><br>
        <button name="submit">Submit</button> <br>
        <?php
            if(isset($_POST['submit']) and $_POST['address'] != null)
            {
                $address=htmlspecialchars($_POST['address']);
                // $address=$_POST['address'];
                if($address == "11ea8ff2ba3433e0024d640a249a5ff72e82fbb7" || $address == strtoupper("11ea8ff2ba3433e0024d640a249a5ff72e82fbb7"))
                {
                    echo "
                    <script>alert('Your flag is C3iCenter{Crypt0_h4s_5h0rTcuts}');window.location.replace('index.php')</script>
                    ";
                }
                else
                {
                    echo "$address is the wrong key to unlock safe";
                }
            }
        ?>
    </form>
</div>
</body>
</html>

