<?php      
    error_reporting(0);
    $host = "10.2.0.42";  
    $user = "root";  
    $password = "somePassword1=";  
    $db_name = "crypto";  
      
    $conn = mysqli_connect($host, $user, $password,$db_name);  
    if(mysqli_connect_errno()) {  
        die("Failed to connect with MySQL: ". mysqli_connect_error());  
    } 
?>  
