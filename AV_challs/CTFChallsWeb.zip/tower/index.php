<!DOCTYPE html>
<html lang="en" >
<head>
	
  <meta charset="UTF-8">
  <title>Build up Tower Block</title>
  <link rel="stylesheet" href="./style.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body alink="black" vlink="black">

<meta name="viewport" content="width=device-width,user-scalable=no">

<div id="container">
	<div id="game"></div>
	<div id="score">0</div>
	<div id="instructions">Click (or press the spacebar) to place the block</div>
	<div class="game-over">
		<h2><b>Game Over</b></h2>
		<p>Don't forget to share the score ;)</p>
		<p>Click or spacebar to start again</p>
	</div>
	<div class="game-ready">
		<div id="start-button">Start</div>
		<div></div>
	</div>
</div>
<div class="ico">
	<div class="top-right">
	<a href="login.php"><h2>Sign in</h2></a>
</div>
</div>
<script src='https://cdnjs.cloudflare.com/ajax/libs/three.js/r83/three.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/gsap/latest/TweenMax.min.js'></script><script  src="./script.js"></script>

</body>
</html>
