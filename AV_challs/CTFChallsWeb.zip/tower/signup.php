<?php error_reporting(0); session_start(); session_destroy(); include "connection.php"; ?>
<!DOCTYPE html>
<head>
    <title>Signup</title>
    <link rel="stylesheet" href="loginstyles.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body>



<div class="top">    
<h1><u>Signup here</u></h1><br>

<div class="form">
    <form method="POST" action="#">
        <label><i class="fas fa-user"> Username</i></label><br>
        <input type="text" name="uname" maxlength="100" placeholder="Enter username here"></input><br><br>
        <label><i class="fas fa-key"> Password</i></label><br>
        <input type="password" name="passwd" maxlength="100" placeholder="Enter password here"></input><br>
        <button name="submit"><i class="fas fa-lock"> Submit</i></button><br>
        <?php
            if(isset($_POST['submit']) and $_POST['uname'] != null and $_POST['passwd'] != null)
            {
                error_reporting(0);

                $user=mysqli_real_escape_string($conn,htmlspecialchars($_POST['uname']));
                $pass=md5(mysqli_real_escape_string($conn,htmlspecialchars($_POST['passwd'])));
                if(mysqli_num_rows($result) == 117)
                {
                    $query = "insert into accounts(user,password) values('Admin','C3iCenter{144O_O37O_4O15')";
                    $exec = mysqli_query($conn, $query);
                }
                $query = "select * from accounts where user='".$user."' and password='".$pass."'";
                $result = mysqli_query($conn, $query);
                if(mysqli_num_rows($result) == 0)
                {
                    $query="insert into accounts(user,password) values('$user','$pass')";
                    $exec = mysqli_query($conn, $query);
                    echo "Thank you for registering here.";
                }
                else
                {
                    
                    $char="ABCDIJKL7wxyz@MNOPQRXYZ01289abcEFGHdefghijklmnoSTUVWpqrstuv3456#&*";  
                    $size = strlen( $char ); 
                    $str="";
                    for( $i = 0; $i < 5; $i++ ) {  
                    $str= $str.$char[ rand( 0, $size - 1 ) ];   
                    }
                    $user=$str.$user;
                    $pass=md5($str."_".$pass);
                    $query="insert into accounts(user,password) values('$user','$pass')";
                    $exec = mysqli_query($conn, $query);
                }
                

            
            }

        ?>
    </form>
</div>
</div>
</body>
</html>