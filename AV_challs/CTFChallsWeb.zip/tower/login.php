<?php  session_start(); session_destroy(); include "connection.php";   
?>
<!DOCTYPE html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="loginstyles.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body>



<div class="top">    
<h1><u>Login here to play more games :)</u></h1><br>

<div class="form">
    <form method="POST" action="#">
        <label><i class="fas fa-user"> Username</i></label><br>
        <input type="text" name="uname" maxlength="100" placeholder="Enter username here"></input><br><br>
        <label><i class="fas fa-key"> Password</i></label><br>
        <input type="password" name="passwd" maxlength="100" placeholder="Enter password here"></input><br><br>
        <input type="hidden" name="token" maxlength="100" value="<?php echo $jwt;?>" readonly required>
        <button name="submit">Submit</button><br>
        <a href="signup.php">Click here to signup</a>
        <?php
            error_reporting(0);
            if(isset($_POST['submit']) and $_POST['uname'] != null and $_POST['passwd'] != null )
            {
                $query = "select * from accounts";
                $result = mysqli_query($conn, $query);
                if(mysqli_num_rows($result) == 117)
                {
                    $query = "insert into accounts(user,password) values('Admin','C3iCenter{144O_O37O_4O15')";
                    $exec = mysqli_query($conn, $query);
                }
                $user=mysqli_real_escape_string($conn,htmlspecialchars($_POST['uname']));
                $pass=md5(mysqli_real_escape_string($conn,htmlspecialchars($_POST['passwd'])));
                $query = "select * from accounts where user='".$user."' and password='".$pass."'";
                $result = mysqli_query($conn, $query);
                if(mysqli_num_rows($result) == 0)
                {
                    $query="insert into accounts(user,password) values('$user','$pass')";
                    $exec = mysqli_query($conn, $query);
                }
                else
                {?>
                   
                    <?php  
                    $pic = array("meme1.jpg","meme2.jpg","james.jpg","meme3.jpg","meme4.jpg");  
                    shuffle($pic);  
                    ?>  
                     
                    <?php  
                        for( $i = 0; $i < 1; $i++)  
                              echo "<li style=\"display: inline;\"> 
                                        <center><img src=\"zXr/$pic[$i]\"  height=\"300\" width=\"35%\"> </center>
                                        </li>";  
                       
                }
            }
            if (isset($_POST['submit']) and ($_POST['uname'] == null or $_POST['passwd'] == null))
            {
                echo "All fields are necessary";
            }

        ?>
        <br>
       
    </form>
</div>
</div>
</body>
</html>