<?php  session_start(); 
if($_SESSION['isadmin']!=="Y")
{
	session_destroy();
    header("Location: index.php");
}   
include "connection.php";

?>
<!DOCTYPE html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="loginstyles.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body>



<div class="top">    
<h1><u>Login here</u></h1><br>

<div class="form">
    <form method="POST" action="#">
        <label><i class="fas fa-user"> Username</i></label><br>
        <input type="text" name="uname"  placeholder="Enter username here"></input><br><br>
        <label><i class="fas fa-key"> Password</i></label><br>
        <input type="password" name="passwd" placeholder="Enter password here"></input><br>
        <button name="submit">Submit</button><br>
        <?php
            
            if(isset($_POST['submit']) and $_POST['uname'] != null and $_POST['passwd'] != null)
            {
                $query='select user,pass from t203 where user=\''.$_POST['uname'].'\' and pass=\''.$_POST['passwd'].'\'';
                // echo $query;
				$execute=mysqli_query($conn,$query);
				if(mysqli_num_rows($execute)>0)
				{
                    if(!(  strpos($query, 'or ')  or  strpos($query, 'oR ')  or strpos($query, 'Or ')  or strpos($query, 'OR ') )){
                        // echo "<br>in<br>";
                        while ($row=mysqli_fetch_row($execute)) {
                            print_r ($row);
                          }
                        //   print_r ($row);
                        if($_POST['uname'] == "Administrator" and $_POST['passwd'] == "pl3@5E_l3tM3_!nn")
                        {
                            session_start();
                            $_SESSION['admin']="Y";
                            header("Location: flag.php");
                        }
                    } 
				}
				else
				{
					echo "<p style='color:red;text-align:center;'>Invalid username or password</p>";
				}	

            }
            if (isset($_POST['submit']) and ($_POST['uname'] == null or $_POST['passwd'] == null))
            {
                echo "All fields are necessary";
            }

        ?>
        <br>
    </form>
</div>
</div>
</body>
</html>