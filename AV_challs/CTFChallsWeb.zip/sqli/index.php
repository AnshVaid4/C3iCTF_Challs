<?php
error_reporting(0);

include "connection.php";
$id=mysqli_real_escape_string($conn,htmlspecialchars($_GET['id']));
$query="select * from users where id='".$id."'";
$execute=mysqli_query($conn,$query);
if(mysqli_num_rows($execute) == 1)
{
	$row=mysqli_fetch_row($execute);
	$uid=$row[0];
	$name=$row[1];
	$jobtitle=$row[2];
	$location=$row[3];
	$department=$row[4];
	$posted=$row[5];
	$description=$row[6];
}
else
{
	if($id == 0)
	{
		echo "
			<script>
			location.replace('index.php?id=0');
			</script>
			";
	}

	if($id < 0)
	{
		echo "
			<script>
			location.replace('index.php?id=7');
			</script>
			";
	}

	if($id > 0)
	{
		echo "
			<script>
			location.replace('index.php?id=0');
			</script>
			";
	}
}
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title><?php 
	if($name == null)
	{
		echo "Someone";
	} 
  echo $name;?>'s Profile</title>
  <link rel="stylesheet" type="text/css" href="//cloud.webtype.com/css/310d85fe-2595-4325-b12b-7efc76721ac9.css" />
<link rel="stylesheet" type="text/css" href="//cloud.typography.com/6770092/738666/css/fonts.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<meta name="viewport" content="width=device-width"><link rel="stylesheet" href="./style.css">

</head>
<body>

<?php
if($jobtitle == 'Admin')
{
	session_start();
	$_SESSION['isadmin']="Y";
?>
<a href="login.php">Login</a>
<?php }?>

<!-- card -->

<ul class="cards">
  
  <li class="card">
    <h1>Profile</h1>
    <h2>EID: <u><?php echo ((($uid*2375)/5)+7);?></u> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Name: <u><?php echo $name;?></u></h2>
    <p><?php echo $description;?></p>
  </li>
</ul>
<!-- partial -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/cash/1.3.0/cash.min.js'></script>

<!-- card end -->



<table>
<caption id="caption">Summary</caption>
	<thead>
		<tr>
			<th>Job Title</th>
			<th>Location</th>
			<th>Department</th>
			<th>Posted</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td aria-label="Job Title">
				<a href="#"><?php echo $jobtitle;?></a>
			</td>
			<td aria-label="Location"><?php echo $location;?></td>
			<td aria-label="Department"><?php echo $department;?></td>
			<td aria-label="Posted"><?php echo $posted;?></td>
		</tr>
		
	</tbody>
</table>
<!-- partial -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
</body>
</html>
