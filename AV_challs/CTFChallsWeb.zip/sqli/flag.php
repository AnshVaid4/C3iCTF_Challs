<?php error_reporting(0); session_start(); 
if ($_SESSION['admin']!="Y")
{session_destroy();
header("Location: login.php");}
else{
    echo "C3iCenter{U53rD4t@_bR34c#3D_}";
}
session_destroy();
?>