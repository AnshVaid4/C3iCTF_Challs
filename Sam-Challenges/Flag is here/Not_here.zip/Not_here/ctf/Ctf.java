// 
// Decompiled by Procyon v0.5.36
// 

package ctf;

public class Ctf
{
    static String flag;
    
    public static void main(final String[] args) {
        if (args.length < 10) {
            System.out.println("No");
            return;
        }
        final ooo o = new ooo();
        Ctf.flag = o._2(Ctf.flag, args);
        System.out.println(Ctf.flag);
        System.out.println(o._1(Ctf.flag));
    }
    
    static {
        Ctf.flag = "|$|&^&@|*Q}&,);\\('))[\\[$`z|_^#(N*]>&)'$p$#(:Q[$;&$2\\_V']?&>u,&)!{`- dG,%V ~<`y ._@'e::1 _\\_{k}-|w _d[&{<`~$)V ?'?9 (!$,.{>? @!^:#|,?')`G[,`Q ;?!_:$$<)F}$:U [|^?)kR _&><.:.-{&[|&\\*;*)F9 -($.>>(<^';#@?,,\\`|)$ <):@(;}?-[~(&)>>*)NQE (~)`$:[;>!.&%<!.>~ %}*:(&:~:<)*>xWN ((!?.#@*<*{-,[@{%!~)~-~:@:#|![>)]?];;$-<}>!@~)<<)1NJT1  \\_!|]#,&!,@>\\[]| ]\\^[?>$|$?'|,#.)$[^@.~!VT   \\;-&,;,!['@[*~#`[*&%<,~]?~_^~(;}\\$>)[&@) Li4   (]}];;*^<)''@\\[.@! *.<--,:-#`-.}<-|)^@](?; uf>-}.%.?}@<!())] <&@(<*$\\((Q=";
    }
}
